package com.example.tvremote

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.ConsumerIrManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

@SuppressLint("MissingPermission", "SetJavaScriptEnabled")
class MainActivity : Activity() {
    private lateinit var web: WebView
    private val exec = Executors.newSingleThreadExecutor()
    private var ir: ConsumerIrManager? = null
    private var hid: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null

    // Keyboard (id 1), mouse (id 2) and consumer-control (id 3) in one HID descriptor.
    private val desc = intArrayOf(
        0x05,0x01,0x09,0x06,0xA1,0x01,0x85,0x01,0x05,0x07,0x19,0xE0,0x29,0xE7,0x15,0x00,0x25,0x01,0x75,0x01,0x95,0x08,0x81,0x02,
        0x95,0x01,0x75,0x08,0x81,0x01,0x95,0x06,0x75,0x08,0x15,0x00,0x25,0x65,0x05,0x07,0x19,0x00,0x29,0x65,0x81,0x00,0xC0,
        0x05,0x01,0x09,0x02,0xA1,0x01,0x85,0x02,0x09,0x01,0xA1,0x00,0x05,0x09,0x19,0x01,0x29,0x03,0x15,0x00,0x25,0x01,0x95,0x03,
        0x75,0x01,0x81,0x02,0x95,0x01,0x75,0x05,0x81,0x01,0x05,0x01,0x09,0x30,0x09,0x31,0x09,0x38,0x15,0x81,0x25,0x7F,0x75,0x08,
        0x95,0x03,0x81,0x06,0xC0,0xC0,
        0x05,0x0C,0x09,0x01,0xA1,0x01,0x85,0x03,0x15,0x00,0x26,0xFF,0x03,0x19,0x00,0x2A,0xFF,0x03,0x75,0x10,0x95,0x01,0x81,0x00,0xC0
    ).map { it.toByte() }.toByteArray()

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            push(if (registered) "ready" else "off")
        }
        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> { host = device; push("connected") }
                BluetoothProfile.STATE_CONNECTING -> push("connecting")
                else -> { if (host == device) host = null; push("ready") }
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = 0xFF06080B.toInt()
        ir = getSystemService(CONSUMER_IR_SERVICE) as? ConsumerIrManager
        web = WebView(this)
        web.setBackgroundColor(0xFF06080B.toInt())
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Native")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    override fun onDestroy() { hid?.unregisterApp(); super.onDestroy() }

    private fun push(s: String) = web.post { web.evaluateJavascript("window.onNative&&onNative('$s')", null) }
    private fun btOk() = Build.VERSION.SDK_INT < 31 ||
        checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    private fun adapter() = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private fun report(id: Int, data: ByteArray) { host?.let { hid?.sendReport(it, id, data) } }

    inner class Bridge {
        @Suppress("DEPRECATION")
        @JavascriptInterface fun bar(hex: String, light: Boolean) = runOnUiThread {
            val c = Color.parseColor(hex)
            window.statusBarColor = c
            web.setBackgroundColor(c)
            window.decorView.systemUiVisibility = if (light) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else 0
        }

        @JavascriptInterface fun hasIr() = ir?.hasIrEmitter() == true

        /** Samsung32: 38 kHz, 4500/4500 header, 560 mark, 1690/560 space, MSB first, 560 stop mark. */
        @JavascriptInterface fun irSend(hex: String): Boolean {
            val m = ir ?: return false
            if (!m.hasIrEmitter()) return false
            val v = hex.toLong(16)
            val p = ArrayList<Int>(67)
            p.add(4500); p.add(4500)
            for (i in 31 downTo 0) { p.add(560); p.add(if (((v shr i) and 1L) == 1L) 1690 else 560) }
            p.add(560)
            m.transmit(38000, p.toIntArray())
            return true
        }

        @JavascriptInterface fun btList(): String {
            val arr = JSONArray()
            if (btOk()) adapter()?.bondedDevices?.forEach { arr.put(JSONObject().put("name", it.name ?: it.address).put("addr", it.address)) }
            return arr.toString()
        }

        @JavascriptInterface fun btStart(): String {
            if (!btOk()) { requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1); return "perm" }
            val a = adapter() ?: return "none"
            if (!a.isEnabled) return "off"
            a.getProfileProxy(this@MainActivity, object : BluetoothProfile.ServiceListener {
                override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                    hid = proxy as BluetoothHidDevice
                    val sdp = BluetoothHidDeviceAppSdpSettings("TV Remote", "Phone remote", "TV Remote",
                        BluetoothHidDevice.SUBCLASS1_COMBO, desc)
                    hid!!.registerApp(sdp, null, null, exec, callback)
                }
                override fun onServiceDisconnected(profile: Int) { hid = null; host = null; push("off") }
            }, BluetoothProfile.HID_DEVICE)
            return "starting"
        }

        @JavascriptInterface fun btConnect(addr: String) {
            val a = adapter() ?: return
            hid?.connect(a.getRemoteDevice(addr))
        }

        @JavascriptInterface fun btKey(usage: Int, mod: Int) = exec.execute {
            report(1, byteArrayOf(mod.toByte(), 0, usage.toByte(), 0, 0, 0, 0, 0))
            Thread.sleep(25)
            report(1, ByteArray(8))
        }

        @JavascriptInterface fun btConsumer(usage: Int) = exec.execute {
            report(3, byteArrayOf((usage and 0xFF).toByte(), (usage shr 8).toByte()))
            Thread.sleep(25)
            report(3, byteArrayOf(0, 0))
        }

        /** btn: 1 = left click (press and release). */
        @JavascriptInterface fun btMouse(dx: Int, dy: Int, btn: Int, wheel: Int) = exec.execute {
            fun c(x: Int) = x.coerceIn(-127, 127).toByte()
            report(2, byteArrayOf(btn.toByte(), c(dx), c(dy), c(wheel)))
            if (btn != 0) { Thread.sleep(25); report(2, byteArrayOf(0, 0, 0, 0)) }
        }

        /** Types ASCII text. Returns how many characters could be mapped. */
        @JavascriptInterface fun btText(s: String): Int {
            exec.execute {
                for (ch in s) {
                    val (u, mod) = usage(ch) ?: continue
                    report(1, byteArrayOf(mod.toByte(), 0, u.toByte(), 0, 0, 0, 0, 0)); Thread.sleep(20)
                    report(1, ByteArray(8)); Thread.sleep(20)
                }
            }
            return s.count { usage(it) != null }
        }
    }

    private fun usage(c: Char): Pair<Int, Int>? = when (c) {
        in 'a'..'z' -> Pair(0x04 + (c - 'a'), 0)
        in 'A'..'Z' -> Pair(0x04 + (c - 'A'), 0x02)
        in '1'..'9' -> Pair(0x1E + (c - '1'), 0)
        '0' -> Pair(0x27, 0)
        ' ' -> Pair(0x2C, 0)
        '\n' -> Pair(0x28, 0)
        '.' -> Pair(0x37, 0)
        ',' -> Pair(0x36, 0)
        '-' -> Pair(0x2D, 0)
        '/' -> Pair(0x38, 0)
        '@' -> Pair(0x1F, 0x02)
        '_' -> Pair(0x2D, 0x02)
        else -> null
    }
}
